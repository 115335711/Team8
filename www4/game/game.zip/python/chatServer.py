#!/usr/bin/env python3

from sys import *
from socket import *
from participantServer import *

server = Server("chat", 4000)
